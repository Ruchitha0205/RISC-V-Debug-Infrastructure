`timescale 1ns/1ps

module tb_as_debug_top;

logic clk_i = 0;
logic tck_i = 0;

always #10 clk_i = ~clk_i;
always #5  tck_i = ~tck_i;

logic [63:0] bus_addr_i;
logic [63:0] bus_wdata_i;
logic [63:0] bus_rdata_i;
logic        bus_write_i;
logic        bus_read_i;

// -------------------------------------
// JTAG
// -------------------------------------
logic tms_i;
logic tdi_i;
logic tdo_o;

// -------------------------------------
// RESET
// -------------------------------------
logic rst_i;

// -------------------------------------
// BREAKPOINT
// -------------------------------------
logic [63:0] pc_i;
logic [31:0] instr_i;

logic        hw_bp_enable_i;
logic [63:0] hw_bp_addr_i;

logic        halt_o;

// -------------------------------------
// TRACE
// -------------------------------------
logic        trace_en_i;
logic [3:0]  trace_addr_i;
logic [95:0] trace_data_o;
    // -------------------------------------
    // BUS MONITOR
    // -------------------------------------
    logic [63:0] bus_addr_i;
    logic [63:0] bus_wdata_i;
    logic [63:0] bus_rdata_i;
    
    logic        bus_write_i;
    logic        bus_read_i;

// -------------------------------------
// MEMORY SELECT
// -------------------------------------
logic scan_sel_i;

// -------------------------------------
// IMEM
// -------------------------------------
logic [14:0] imem_addr_i;
logic [31:0] imem_data_i;
logic        imem_wr_i;
logic [31:0] imem_data_o;

// -------------------------------------
// DMEM
// -------------------------------------
logic [12:3] dmem_addr_i;
logic        dmem_wrEn_i;
logic        dmem_rdEn_i;
logic [63:0] dmem_data_i;
logic [7:0]  dmem_byteEn_i;
logic [63:0] dmem_data_o;

integer i;
integer errors;

logic [31:0] shifted_imem;
logic [31:0] new_imem_word;

// -------------------------------------
// DUT
// -------------------------------------
as_debug_top dut (

    .tck_i(tck_i),
    .tms_i(tms_i),
    .tdi_i(tdi_i),
    .tdo_o(tdo_o),

    .clk_i(clk_i),
    .rst_i(rst_i),

    .pc_i(pc_i),
    .instr_i(instr_i),

    .hw_bp_enable_i(hw_bp_enable_i),
    .hw_bp_addr_i(hw_bp_addr_i),

    .halt_o(halt_o),

    .trace_en_i(trace_en_i),
    .trace_addr_i(trace_addr_i),
    .trace_data_o(trace_data_o),

    .scan_sel_i(scan_sel_i),

    .imem_addr_i(imem_addr_i),
    .imem_data_i(imem_data_i),
    .imem_wr_i(imem_wr_i),
    .imem_data_o(imem_data_o),

    .dmem_addr_i(dmem_addr_i),
    .dmem_wrEn_i(dmem_wrEn_i),
    .dmem_rdEn_i(dmem_rdEn_i),
    .dmem_data_i(dmem_data_i),
    .dmem_byteEn_i(dmem_byteEn_i),
    .dmem_data_o(dmem_data_o)
);

// -------------------------------------
// TEST
// -------------------------------------
initial begin

    errors = 0;

    rst_i = 1;

    tms_i = 1;
    tdi_i = 0;

    scan_sel_i = 0;

    imem_addr_i = 20;
    imem_data_i = 0;
    imem_wr_i   = 0;

    dmem_addr_i = 0;
    dmem_wrEn_i = 0;
    dmem_rdEn_i = 0;
    dmem_data_i = 0;
    dmem_byteEn_i = 8'hFF;

    pc_i = 0;
    instr_i = 0;

    hw_bp_enable_i = 0;
    hw_bp_addr_i   = 0;

    trace_en_i = 0;
    trace_addr_i = 0;

    bus_addr_i  = 64'h0;
    bus_wdata_i = 64'h0;
    bus_rdata_i = 64'h0;
    
    bus_write_i = 1'b0;
    bus_read_i  = 1'b0;
    new_imem_word = 32'hAABBCCDD;

    #50;
    rst_i = 0;

    $display("--------------------------------");
    $display("DEBUG TOP TEST");
    $display("--------------------------------");

    //------------------------------------------------
    // TEST 1 : IMEM READ
    //------------------------------------------------
    @(posedge clk_i);

    if(imem_data_o !== 32'h12345678) begin
        $display("FAIL IMEM READ");
        errors++;
    end
    else
        $display("PASS IMEM READ");

    //------------------------------------------------
    // TEST 2 : SCAN CAPTURE
    //------------------------------------------------

    //------------------------------------------------
// TEST 2 : SCAN CAPTURE
//------------------------------------------------

// TAP RESET
tms_i = 1;

repeat(5)
    @(posedge tck_i);

// RESET -> IDLE
tms_i = 0;
@(posedge tck_i);

// IDLE -> CAPTURE
tms_i = 1;
@(posedge tck_i);

// CAPTURE -> SHIFT
tms_i = 0;
@(posedge tck_i);

#1;

    shifted_imem = 32'h0;

for(i=31;i>=0;i=i-1) begin

    shifted_imem[i] = tdo_o;

    tdi_i = 1'b0;

    @(posedge tck_i);
    #1;

end

    if(shifted_imem !== 32'h12345678) begin
        $display("FAIL SCAN OUT = %h", shifted_imem);
        errors++;
    end
    else
        $display("PASS SCAN OUT");

    //------------------------------------------------
    // TEST 3 : HARDWARE BREAKPOINT
    //------------------------------------------------

    hw_bp_enable_i = 1;
hw_bp_addr_i   = 64'h20;

pc_i = 64'h20;

@(posedge clk_i);
#1;

if(!halt_o) begin
        $display("FAIL HW BREAKPOINT");
        errors++;
    end
    else
        $display("PASS HW BREAKPOINT");

    //------------------------------------------------
    // TEST 4 : SOFTWARE BREAKPOINT
    //------------------------------------------------

    hw_bp_enable_i = 0;

    instr_i = 32'h00100073;

    @(posedge clk_i);

    if(!halt_o) begin
        $display("FAIL SW BREAKPOINT");
        errors++;
    end
    else
        $display("PASS SW BREAKPOINT");

    //------------------------------------------------
    // TEST 5 : TRACE BUFFER
    //------------------------------------------------

    trace_en_i = 1;

    pc_i    = 64'h1000;
    instr_i = 32'h11111111;
    @(posedge clk_i);

    pc_i    = 64'h1004;
    instr_i = 32'h22222222;
    @(posedge clk_i);

    pc_i    = 64'h1008;
    instr_i = 32'h33333333;
    @(posedge clk_i);

    trace_en_i = 0;

    trace_addr_i = 0;

    @(posedge clk_i);

    if(trace_data_o !== {64'h1000,32'h11111111}) begin
        $display("FAIL TRACE BUFFER");
        errors++;
    end
    else
        $display("PASS TRACE BUFFER");

    //------------------------------------------------
    // FINAL RESULT
    //------------------------------------------------

    if(errors == 0)
        $display("ALL TESTS PASSED");
    else
        $display("FAILED %0d TESTS", errors);

    #100;
    $finish;

end

endmodule