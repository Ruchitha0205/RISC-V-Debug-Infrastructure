`timescale 1ns/1ps

module tb_asIMem;

  //---------------------------------------
  // CLOCKS
  //---------------------------------------
  logic tck_i;
  logic clk_i;

  initial begin
    tck_i = 0;
    forever #5 tck_i = ~tck_i;
  end

  initial begin
    clk_i = 0;
    forever #10 clk_i = ~clk_i;
  end

  //---------------------------------------
  // DUT SIGNALS
  //---------------------------------------
  logic [14:0] addr_i;
  logic [31:0] data_i;
  logic        wr_i;
  logic [31:0] data_o;

  logic scan_en_i;
  logic scan_capture_i;
  logic scan_shift_i;
  logic scan_update_i;
  logic scan_in_i;
  logic scan_out_o;

  integer errors;
  integer i;

  logic [31:0] shifted_data;
  logic [31:0] new_data;

  //---------------------------------------
  // DUT
  //---------------------------------------
  asIMem dut (
      .tck_i(tck_i),
      .clk_i(clk_i),
      .addr_i(addr_i),
      .data_i(data_i),
      .wr_i(wr_i),
      .data_o(data_o),
      .scan_en_i(scan_en_i),
      .scan_capture_i(scan_capture_i),
      .scan_shift_i(scan_shift_i),
      .scan_update_i(scan_update_i),
      .scan_in_i(scan_in_i),
      .scan_out_o(scan_out_o)
  );

  //---------------------------------------
  // TASK : CHECK
  //---------------------------------------
  task automatic check;
    input [31:0] actual;
    input [31:0] expected;
    input [200:0] msg;
    begin
      if(actual !== expected) begin
        $display("FAIL : %s", msg);
        $display("Expected = %h  Actual = %h",
                  expected, actual);
        errors = errors + 1;
      end
      else begin
        $display("PASS : %s -> %h",
                  msg, actual);
      end
    end
  endtask

  //---------------------------------------
  // TEST
  //---------------------------------------
  initial begin

    errors = 0;

    scan_en_i      = 0;
    scan_capture_i = 0;
    scan_shift_i   = 0;
    scan_update_i  = 0;
    scan_in_i      = 0;

    wr_i           = 0;
    addr_i         = 0;
    data_i         = 0;

    shifted_data   = 0;
    new_data       = 32'hAABBCCDD;

    #50;

    $display("\n=================================");
    $display(" IMEM SCAN CHAIN TEST ");
    $display("=================================");

    //------------------------------------------------
    // TEST 1 : INITIAL MEMORY READ
    //------------------------------------------------
    addr_i = 15'd20; // MEM[5]

    @(posedge clk_i);
    @(posedge clk_i);

    check(data_o,
          32'h12345678,
          "Initial Memory Read");

    //------------------------------------------------
    // TEST 2 : NORMAL WRITE
    //------------------------------------------------
    addr_i = 15'd24; // MEM[6]
    data_i = 32'hDEADBEEF;

    wr_i = 1;
    @(posedge tck_i);
    #1;
    wr_i = 0;

    @(posedge clk_i);
    @(posedge clk_i);

    check(data_o,
          32'hDEADBEEF,
          "Normal Write/Read");

    //------------------------------------------------
    // TEST 3 : SCAN CAPTURE
    //------------------------------------------------
    addr_i         = 15'd20; // MEM[5]

    scan_en_i      = 1;
    scan_capture_i = 1;

    @(posedge tck_i);
    #1;
    scan_capture_i = 0;

    check(dut.scan_sr,
          32'h12345678,
          "Scan Capture");

    //------------------------------------------------
    // TEST 4 : SCAN OUT
    //------------------------------------------------
    shifted_data = 0;

    for(i=31; i>=0; i=i-1) begin

      shifted_data[i] = scan_out_o;

      scan_shift_i = 1;
      @(posedge tck_i);
      #1;
      scan_shift_i = 0;

    end

    check(shifted_data,
          32'h12345678,
          "Scan Out");

    //------------------------------------------------
    // TEST 5 : SCAN WRITE
    //------------------------------------------------

    // Re-capture before loading new data
    scan_capture_i = 1;
    @(posedge tck_i);
    #1;
    scan_capture_i = 0;

    // Shift in new pattern
    for(i=0; i<32; i=i+1) begin

      scan_in_i = new_data[i];

      scan_shift_i = 1;
      @(posedge tck_i);
      #1;
      scan_shift_i = 0;

    end

    check(dut.scan_sr,
          new_data,
          "Shift In New Data");

    // Update memory
    scan_update_i = 1;
    @(posedge tck_i);
    #1;
    scan_update_i = 0;

    scan_en_i = 0;

    addr_i = 15'd20;

    @(posedge clk_i);
    @(posedge clk_i);

    check(data_o,
          new_data,
          "Scan Write");

    //------------------------------------------------
    // TEST 6 : RE-CAPTURE UPDATED MEMORY
    //------------------------------------------------
    scan_en_i      = 1;
    scan_capture_i = 1;

    @(posedge tck_i);
    #1;
    scan_capture_i = 0;

    check(dut.scan_sr,
          new_data,
          "Capture Updated Memory");

    //------------------------------------------------
    // FINAL RESULT
    //------------------------------------------------
    $display("\n=================================");

    if(errors == 0)
      $display("ALL TESTS PASSED");
    else
      $display("FAILED WITH %0d ERRORS", errors);

    $display("=================================\n");

    #50;
    $finish;

  end

endmodule