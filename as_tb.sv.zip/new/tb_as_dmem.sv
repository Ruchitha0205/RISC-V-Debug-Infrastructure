`timescale 1ns/1ps

module tb_as_dmem;

  //---------------------------------------
  // Parameters
  //---------------------------------------
  localparam REG_WIDTH = 64;
  localparam ADDR_WIDTH = 13;

  //---------------------------------------
  // DUT Signals
  //---------------------------------------
  logic clk_i;

  logic [ADDR_WIDTH-1:3] addr_i;
  logic                  wrEn_i;
  logic                  rdEn_i;

  logic [REG_WIDTH-1:0]  data_i;
  logic [7:0]            byteEn_i;

  logic [REG_WIDTH-1:0]  data_o;

  logic                  scan_en_i;
  logic                  scan_capture_i;
  logic                  scan_shift_i;
  logic                  scan_update_i;
  logic                  scan_in_i;
  logic                  scan_out_o;

  integer errors;
  integer i;

  logic [63:0] shifted_data;
  logic [63:0] new_scan_data;

  //---------------------------------------
  // DUT
  //---------------------------------------
  as_dmem dut (
      .clk_i(clk_i),

      .addr_i(addr_i),
      .wrEn_i(wrEn_i),
      .rdEn_i(rdEn_i),

      .data_i(data_i),
      .byteEn_i(byteEn_i),

      .data_o(data_o),

      .scan_en_i(scan_en_i),
      .scan_capture_i(scan_capture_i),
      .scan_shift_i(scan_shift_i),
      .scan_update_i(scan_update_i),
      .scan_in_i(scan_in_i),
      .scan_out_o(scan_out_o)
  );

  //---------------------------------------
  // Clock
  //---------------------------------------
  initial begin
    clk_i = 0;
    forever #5 clk_i = ~clk_i;
  end

  //---------------------------------------
  // Check Task
  //---------------------------------------
  task automatic check;
    input [63:0] actual;
    input [63:0] expected;
    input [200:0] msg;
    begin
      if(actual !== expected) begin
        $display("FAIL : %s", msg);
        $display("Expected = %h", expected);
        $display("Actual   = %h", actual);
        errors = errors + 1;
      end
      else begin
        $display("PASS : %s -> %h", msg, actual);
      end
    end
  endtask

  //---------------------------------------
  // Test Sequence
  //---------------------------------------
  initial begin

    errors = 0;

    addr_i          = 0;
    wrEn_i          = 0;
    rdEn_i          = 0;
    data_i          = 0;
    byteEn_i        = 0;

    scan_en_i       = 0;
    scan_capture_i  = 0;
    scan_shift_i    = 0;
    scan_update_i   = 0;
    scan_in_i       = 0;

    shifted_data    = 0;
    new_scan_data   = 64'hAABBCCDDEEFF0011;

    #50;

    $display("\n======================================");
    $display(" DATA MEMORY SCAN TEST ");
    $display("======================================");

    //--------------------------------------------------
    // TEST 1 : INITIAL MEMORY
    //--------------------------------------------------
    addr_i = 5; // ram_s[5]

    @(posedge clk_i);
    @(posedge clk_i);

    check(data_o,
          64'h1122334455667788,
          "Initial Memory Content");

    //--------------------------------------------------
    // TEST 2 : FULL 64-BIT WRITE
    //--------------------------------------------------
    addr_i   = 10;
    data_i   = 64'hDEADBEEFCAFEBABE;
    byteEn_i = 8'hFF;
    wrEn_i   = 1;

    @(posedge clk_i);

    wrEn_i = 0;

    @(posedge clk_i);
    @(posedge clk_i);

    check(data_o,
          64'hDEADBEEFCAFEBABE,
          "Full 64-bit Write");

    //--------------------------------------------------
    // TEST 3 : BYTE ENABLE WRITE
    //--------------------------------------------------
    addr_i   = 10;
    data_i   = 64'h0000000000001234;
    byteEn_i = 8'b00000011; // lower 2 bytes only
    wrEn_i   = 1;

    @(posedge clk_i);

    wrEn_i = 0;

    @(posedge clk_i);
    @(posedge clk_i);

    check(data_o,
          64'hDEADBEEFCAFE1234,
          "Byte Enable Write");

    //--------------------------------------------------
    // TEST 4 : SCAN CAPTURE
    //--------------------------------------------------
    addr_i         = 5;

    scan_en_i      = 1;
    scan_capture_i = 1;

    @(posedge clk_i);
    #1;

    scan_capture_i = 0;

    check(dut.scan_sr,
          64'h1122334455667788,
          "Scan Capture");

    //--------------------------------------------------
    // TEST 5 : SCAN SHIFT OUT
    //--------------------------------------------------
    shifted_data = 0;

    for(i=63;i>=0;i=i-1) begin

      shifted_data[i] = scan_out_o;

      scan_shift_i = 1;
      @(posedge clk_i);
      #1;
      scan_shift_i = 0;

    end

    check(shifted_data,
          64'h1122334455667788,
          "Scan Shift Out");

    //--------------------------------------------------
    // TEST 6 : SHIFT IN NEW DATA
    //--------------------------------------------------
    scan_capture_i = 1;

    @(posedge clk_i);
    #1;

    scan_capture_i = 0;

    for(i=0;i<64;i=i+1) begin

      scan_in_i = new_scan_data[i];

      scan_shift_i = 1;
      @(posedge clk_i);
      #1;
      scan_shift_i = 0;

    end

    check(dut.scan_sr,
          new_scan_data,
          "Shift In New Data");

    //--------------------------------------------------
    // TEST 7 : SCAN UPDATE
    //--------------------------------------------------
    scan_update_i = 1;

    @(posedge clk_i);
    #1;

    scan_update_i = 0;

    scan_en_i = 0;

    addr_i = 5;

    @(posedge clk_i);
    @(posedge clk_i);

    check(data_o,
          new_scan_data,
          "Scan Update Memory");

    //--------------------------------------------------
    // TEST 8 : RE-CAPTURE
    //--------------------------------------------------
    scan_en_i      = 1;
    scan_capture_i = 1;

    @(posedge clk_i);
    #1;

    scan_capture_i = 0;

    check(dut.scan_sr,
          new_scan_data,
          "Capture Updated Memory");

    //--------------------------------------------------
    // Summary
    //--------------------------------------------------
    $display("\n======================================");

    if(errors == 0)
      $display("ALL TESTS PASSED");
    else
      $display("FAILED WITH %0d ERRORS", errors);

    $display("======================================\n");

    #50;
    $finish;

  end

endmodule