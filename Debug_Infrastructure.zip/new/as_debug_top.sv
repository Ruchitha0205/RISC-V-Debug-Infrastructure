// as_debug_top.sv
`timescale 1ns/1ps

module as_debug_top #(
    parameter int instr_width     = 32,
    parameter int imem_addr_width = 15,

    parameter int reg_width       = 64,
    parameter int dmem_addr_width = 13
)(


    // =====================================
    // JTAG INTERFACE
    // =====================================
    input  logic tck_i,
    input  logic tms_i,
    input  logic tdi_i,
    output logic tdo_o,
    
    // Breakpoint signals
    input  logic [63:0] pc_i,
    input  logic        hw_bp_enable_i,
    input  logic [63:0] hw_bp_addr_i,
    input  logic [31:0] instr_i,
    output logic        halt_o,
    // Trace
    input  logic rst_i,
    input  logic trace_en_i,
    
    input  logic [3:0] trace_addr_i,
    
    output logic [95:0] trace_data_o,
    // =====================================

    // BUS MONITOR
    // =====================================
    input logic [63:0] bus_addr_i,
    input logic [63:0] bus_wdata_i,
    input logic [63:0] bus_rdata_i,
    
    input logic        bus_write_i,
    input logic        bus_read_i,
    
    // =====================================
    // SYSTEM CLOCK
    // =====================================
    input  logic clk_i,

    // =====================================
    // MEMORY SELECT
    // 0 = IMEM
    // 1 = DMEM
    // =====================================
    input  logic scan_sel_i,

    // =====================================
    // IMEM INTERFACE
    // =====================================
    input  logic [imem_addr_width-1:0] imem_addr_i,
    input  logic [instr_width-1:0]     imem_data_i,
    input  logic                       imem_wr_i,
    output logic [instr_width-1:0]     imem_data_o,

    // =====================================
    // DMEM INTERFACE
    // =====================================
    input  logic [dmem_addr_width-1:3] dmem_addr_i,
    input  logic                       dmem_wrEn_i,
    input  logic                       dmem_rdEn_i,
    input  logic [reg_width-1:0]       dmem_data_i,
    input  logic [7:0]                 dmem_byteEn_i,
    output logic [reg_width-1:0]       dmem_data_o
);

    // =====================================
    // INTERNAL SCAN SIGNALS
    // =====================================
    logic scan_en_s;
    logic scan_capture_s;
    logic scan_shift_s;
    logic scan_update_s;

    logic scan_in_s;
    logic scan_out_s;
    logic bus_scan_out;

    // =====================================
    // TAP CONTROLLER
    // =====================================
    as_tap_controller u_tap (

        // JTAG
        .tck_i(tck_i),
        .tms_i(tms_i),
        .tdi_i(tdi_i),
        .tdo_o(tdo_o),

        // Scan chain connection
        .scan_out_i(scan_out_s),

        .scan_en_o(scan_en_s),
        .scan_capture_o(scan_capture_s),
        .scan_shift_o(scan_shift_s),
        .scan_update_o(scan_update_s),

        .scan_in_o(scan_in_s)
    );
    

    // =====================================
    // SCAN SYSTEM TOP
    // =====================================
    as_scan_top u_scan_top (

        // clocks
        .clk_i(clk_i),
        .tck_i(tck_i),

        // scan control
        .scan_en_i(scan_en_s),
        .scan_capture_i(scan_capture_s),
        .scan_shift_i(scan_shift_s),
        .scan_update_i(scan_update_s),

        .scan_in_i(scan_in_s),
        .scan_out_o(scan_out_s),

        // memory select
        .scan_sel_i(scan_sel_i),

        // ---------------------------------
        // IMEM
        // ---------------------------------
        .imem_addr_i(imem_addr_i),
        .imem_data_i(imem_data_i),
        .imem_wr_i(imem_wr_i),
        .imem_data_o(imem_data_o),

        // ---------------------------------
        // DMEM
        // ---------------------------------
        .dmem_addr_i(dmem_addr_i),
        .dmem_wrEn_i(dmem_wrEn_i),
        .dmem_rdEn_i(dmem_rdEn_i),
        .dmem_data_i(dmem_data_i),
        .dmem_byteEn_i(dmem_byteEn_i),
        .dmem_data_o(dmem_data_o)
    );
    
    // =====================================
// BREAKPOINT UNIT
// =====================================
as_breakpoint u_breakpoint (

    .clk_i(clk_i),

    .hw_bp_enable_i(hw_bp_enable_i),
    .hw_bp_addr_i  (hw_bp_addr_i),

    .pc_i   (pc_i),
    .instr_i(instr_i),

    .halt_o(halt_o)
 );
 as_trace_buffer u_trace (

    .clk_i(clk_i),
    .rst_i(rst_i),

    .pc_i(pc_i),
    .instr_i(instr_i),

    .trace_en_i(trace_en_i),

    .trace_addr_i(trace_addr_i),

    .trace_data_o(trace_data_o)
);

as_bus_monitor u_bus_monitor (

    .clk_i(clk_i),

    .addr_i(bus_addr_i),
    .wdata_i(bus_wdata_i),
    .rdata_i(bus_rdata_i),

    .write_i(bus_write_i),
    .read_i(bus_read_i),

    .scan_capture_i(scan_capture_s),
    .scan_shift_i(scan_shift_s),
    .scan_update_i(scan_update_s),

    .scan_in_i(scan_in_s),

    .scan_out_o(bus_scan_out)
);

endmodule