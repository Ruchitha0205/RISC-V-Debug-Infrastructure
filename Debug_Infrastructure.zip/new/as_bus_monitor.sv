`timescale 1ns/1ps

module as_bus_monitor #(
    parameter ADDR_WIDTH = 64,
    parameter DATA_WIDTH = 64
)(
    input logic clk_i,

    // Bus signals
    input logic [ADDR_WIDTH-1:0] addr_i,
    input logic [DATA_WIDTH-1:0] wdata_i,
    input logic [DATA_WIDTH-1:0] rdata_i,
    input logic                  write_i,
    input logic                  read_i,

    // JTAG Scan Control
    input logic scan_capture_i,
    input logic scan_shift_i,
    input logic scan_update_i,
    input logic scan_in_i,

    output logic scan_out_o
);

localparam SCAN_WIDTH =
      ADDR_WIDTH
    + DATA_WIDTH
    + DATA_WIDTH
    + 2;

logic [SCAN_WIDTH-1:0] scan_reg;

always_ff @(posedge clk_i) begin

    if (scan_capture_i) begin

        scan_reg <= {
            addr_i,
            wdata_i,
            rdata_i,
            write_i,
            read_i
        };

    end
    else if (scan_shift_i) begin

        scan_reg <= {
            scan_in_i,
            scan_reg[SCAN_WIDTH-1:1]
        };

    end

end



assign scan_out_o = scan_reg[0];

endmodule