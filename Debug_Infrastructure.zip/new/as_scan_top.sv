// as_scan_top.sv
`timescale 1ns/1ps

module as_scan_top #(
    parameter int instr_width     = 32,
    parameter int imem_addr_width = 15,

    parameter int reg_width       = 64,
    parameter int dmem_addr_width = 13
)(

    // --------------------------------------
    // CLOCKS
    // --------------------------------------
    input  logic clk_i,
    input  logic tck_i,

    // --------------------------------------
    // GLOBAL SCAN CONTROL
    // --------------------------------------
    input  logic scan_en_i,
    input  logic scan_capture_i,
    input  logic scan_shift_i,
    input  logic scan_update_i,

    input  logic scan_in_i,
    output logic scan_out_o,

    // --------------------------------------
    // SCAN SELECT
    // 0 = IMEM
    // 1 = DMEM
    // --------------------------------------
    input  logic scan_sel_i,

    // ======================================
    // IMEM INTERFACE
    // ======================================
    input  logic [imem_addr_width-1:0] imem_addr_i,
    input  logic [instr_width-1:0]     imem_data_i,
    input  logic                       imem_wr_i,
    output logic [instr_width-1:0]     imem_data_o,

    // ======================================
    // DMEM INTERFACE
    // ======================================
    input  logic [dmem_addr_width-1:3] dmem_addr_i,
    input  logic                       dmem_wrEn_i,
    input  logic                       dmem_rdEn_i,
    input  logic [reg_width-1:0]       dmem_data_i,
    input  logic [7:0]                 dmem_byteEn_i,
    output logic [reg_width-1:0]       dmem_data_o
);

    // --------------------------------------
    // INTERNAL SCAN SIGNALS
    // --------------------------------------
    logic imem_scan_out;
    logic dmem_scan_out;

    // ======================================
    // IMEM INSTANCE
    // ======================================
    as_imem u_imem (

        .tck_i(tck_i),
        .clk_i(clk_i),

        .addr_i(imem_addr_i),
        .data_i(imem_data_i),
        .wr_i(imem_wr_i),
        .data_o(imem_data_o),

        // Scan
        .scan_en_i     (scan_en_i && (scan_sel_i == 1'b0)),
        .scan_capture_i(scan_capture_i),
        .scan_shift_i  (scan_shift_i),
        .scan_update_i (scan_update_i),
        .scan_in_i     (scan_in_i),
        .scan_out_o    (imem_scan_out)
    );

    // ======================================
    // DMEM INSTANCE
    // ======================================
    as_dmem u_dmem (

        .clk_i(clk_i),

        .addr_i(dmem_addr_i),
        .wrEn_i(dmem_wrEn_i),
        .rdEn_i(dmem_rdEn_i),

        .data_i(dmem_data_i),
        .byteEn_i(dmem_byteEn_i),

        .data_o(dmem_data_o),

        // Scan
        .scan_en_i     (scan_en_i && (scan_sel_i == 1'b1)),
        .scan_capture_i(scan_capture_i),
        .scan_shift_i  (scan_shift_i),
        .scan_update_i (scan_update_i),
        .scan_in_i     (scan_in_i),
        .scan_out_o    (dmem_scan_out)
    );

    // ======================================
    // GLOBAL SCAN OUTPUT MUX
    // ======================================
    assign scan_out_o =
        (scan_sel_i == 1'b0) ? imem_scan_out :
                               dmem_scan_out;

endmodule