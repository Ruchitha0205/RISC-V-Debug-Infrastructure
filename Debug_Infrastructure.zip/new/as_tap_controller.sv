// as_tap_controller.sv
`timescale 1ns/1ps

module as_tap_controller (

    // --------------------------------------
    // JTAG PORTS
    // --------------------------------------
    input  logic tck_i,
    input  logic tms_i,
    input  logic tdi_i,

    output logic tdo_o,

    // --------------------------------------
    // CONNECTION TO SCAN SYSTEM
    // --------------------------------------
    input  logic scan_out_i,

    output logic scan_en_o,
    output logic scan_capture_o,
    output logic scan_shift_o,
    output logic scan_update_o,

    output logic scan_in_o
);

    // ======================================
    // TAP FSM STATES
    // ======================================
    typedef enum logic [2:0] {
        TEST_RESET = 3'd0,
        IDLE       = 3'd1,
        CAPTURE_DR = 3'd2,
        SHIFT_DR   = 3'd3,
        UPDATE_DR  = 3'd4
    } tap_state_t;

    tap_state_t state_r = TEST_RESET;
    tap_state_t state_n;

    // ======================================
    // STATE REGISTER
    // ======================================
    always_ff @(posedge tck_i) begin
        state_r <= state_n;
    end

    // ======================================
    // NEXT STATE LOGIC
    // ======================================
    always_comb begin

        state_n = state_r;

        case (state_r)

            // ---------------------------------
            // RESET
            // ---------------------------------
            TEST_RESET: begin
                if (tms_i)
                    state_n = TEST_RESET;
                else
                    state_n = IDLE;
            end

            // ---------------------------------
            // IDLE
            // ---------------------------------
            IDLE: begin
                if (tms_i)
                    state_n = CAPTURE_DR;
                else
                    state_n = IDLE;
            end

            // ---------------------------------
            // CAPTURE
            // ---------------------------------
            CAPTURE_DR: begin
                if (tms_i)
                    state_n = UPDATE_DR;
                else
                    state_n = SHIFT_DR;
            end

            // ---------------------------------
            // SHIFT
            // ---------------------------------
            SHIFT_DR: begin
                if (tms_i)
                    state_n = UPDATE_DR;
                else
                    state_n = SHIFT_DR;
            end

            // ---------------------------------
            // UPDATE
            // ---------------------------------
            UPDATE_DR: begin
                if (tms_i)
                    state_n = TEST_RESET;
                else
                    state_n = IDLE;
            end

            default:
                state_n = TEST_RESET;

        endcase
    end

    // ======================================
    // OUTPUT LOGIC
    // ======================================
    always_comb begin

        // defaults
        scan_en_o      = 1'b0;
        scan_capture_o = 1'b0;
        scan_shift_o   = 1'b0;
        scan_update_o  = 1'b0;

        case (state_r)

            CAPTURE_DR: begin
                scan_en_o      = 1'b1;
                scan_capture_o = 1'b1;
            end

            SHIFT_DR: begin
                scan_en_o    = 1'b1;
                scan_shift_o = 1'b1;
            end

            UPDATE_DR: begin
                scan_en_o      = 1'b1;
                scan_update_o  = 1'b1;
            end

            default: begin
                scan_en_o      = 1'b0;
                scan_capture_o = 1'b0;
                scan_shift_o   = 1'b0;
                scan_update_o  = 1'b0;
            end

        endcase
    end

    // ======================================
    // SCAN CONNECTIONS
    // ======================================
    assign scan_in_o = tdi_i;

    assign tdo_o = scan_out_i;

endmodule