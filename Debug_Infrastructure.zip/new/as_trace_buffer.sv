`timescale 1ns/1ps

module as_trace_buffer #(
    parameter int TRACE_DEPTH = 16,
    parameter int PC_WIDTH    = 64,
    parameter int INSTR_WIDTH = 32
)(
    input  logic                     clk_i,
    input  logic                     rst_i,

    // Processor activity
    input  logic [PC_WIDTH-1:0]      pc_i,
    input  logic [INSTR_WIDTH-1:0]   instr_i,

    // Trace enable
    input  logic                     trace_en_i,

    // Debug read interface
    input  logic [$clog2(TRACE_DEPTH)-1:0] trace_addr_i,

    output logic [PC_WIDTH+INSTR_WIDTH-1:0] trace_data_o
);

    // -----------------------------------
    // Trace Memory
    // -----------------------------------
    logic [PC_WIDTH+INSTR_WIDTH-1:0]
          trace_mem [0:TRACE_DEPTH-1];

    logic [$clog2(TRACE_DEPTH)-1:0] wr_ptr;

    integer i;

    // -----------------------------------
    // Reset
    // -----------------------------------
    always_ff @(posedge clk_i) begin

        if(rst_i) begin

            wr_ptr <= '0;

            for(i=0;i<TRACE_DEPTH;i=i+1)
                trace_mem[i] <= '0;

        end
        else begin

            if(trace_en_i) begin

                trace_mem[wr_ptr]
                    <= {pc_i,instr_i};

                wr_ptr <= wr_ptr + 1'b1;

            end

        end

    end

    // -----------------------------------
    // Read Trace Entry
    // -----------------------------------
    assign trace_data_o =
           trace_mem[trace_addr_i];

endmodule