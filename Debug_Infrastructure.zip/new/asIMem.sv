`timescale 1ns/1ps

module as_imem #(
  parameter int instr_width     = 32,
  parameter int imem_addr_width = 15,
  parameter int imemdepth       = 8192
)(
    input  logic                        tck_i,
    input  logic                        clk_i,

    input  logic [imem_addr_width-1:0]  addr_i,
    input  logic [instr_width-1:0]      data_i,
    input  logic                        wr_i,

    output logic [instr_width-1:0]      data_o,

    // --------------------------------------
    // SCAN CHAIN INTERFACE
    // --------------------------------------
    input  logic                        scan_en_i,
    input  logic                        scan_capture_i,
    input  logic                        scan_shift_i,
    input  logic                        scan_update_i,
    input  logic                        scan_in_i,
    output logic                        scan_out_o
);

  localparam int mdepth = imemdepth;

  // --------------------------------------
  // Instruction Memory
  // --------------------------------------
  (* ram_style = "block" *)
  logic [instr_width-1:0] iram_s [0:mdepth-1];

  // --------------------------------------
  // Scan Register
  // --------------------------------------
  logic [instr_width-1:0] scan_sr;

  integer i;

  // --------------------------------------
  // INITIAL MEMORY CONTENTS
  // --------------------------------------
  initial begin

    for (i = 0; i < mdepth; i = i + 1)
      iram_s[i] = 32'h00000000;

    iram_s[0] = 32'h11111111;
    iram_s[1] = 32'h22222222;
    iram_s[2] = 32'h33333333;
    iram_s[3] = 32'h44444444;
    iram_s[4] = 32'h55555555;
    iram_s[5] = 32'h12345678;

  end

  // --------------------------------------
  // NORMAL WRITE
  // --------------------------------------
  always_ff @(posedge tck_i) begin
    if (!scan_en_i) begin
      if (wr_i)
        iram_s[addr_i[imem_addr_width-1:2]] <= data_i;
    end
  end

  // --------------------------------------
  // NORMAL READ
  // --------------------------------------
  always_ff @(posedge clk_i) begin
    data_o <= iram_s[addr_i[imem_addr_width-1:2]];
  end

  // --------------------------------------
  // SCAN CHAIN OPERATIONS
  // --------------------------------------
  always_ff @(posedge tck_i) begin

    if (scan_en_i) begin

      // Capture selected memory word
      if (scan_capture_i)
        scan_sr <= iram_s[addr_i[imem_addr_width-1:2]];

      // Shift LEFT
      else if (scan_shift_i)
        scan_sr <= {scan_sr[instr_width-2:0], scan_in_i};

      // Update memory word
      else if (scan_update_i)
        iram_s[addr_i[imem_addr_width-1:2]] <= scan_sr;

    end

  end

  // --------------------------------------
  // Scan Output = MSB
  // --------------------------------------
  assign scan_out_o = scan_sr[instr_width-1];

endmodule : as_imem