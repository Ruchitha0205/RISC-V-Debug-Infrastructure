// asDMemCore.sv
`timescale 1ns/1ps

module as_dmem #(
  parameter int reg_width       = 64,
  parameter int dmem_addr_width = 13,
  parameter int dmemdepth       = 1024
)(
    input  logic                       clk_i,

    input  logic [dmem_addr_width-1:3] addr_i,
    input  logic                       wrEn_i,
    input  logic                       rdEn_i,

    input  logic [reg_width-1:0]       data_i,
    input  logic [7:0]                 byteEn_i,

    output logic [reg_width-1:0]       data_o,

    // --------------------------------------
    // SCAN CHAIN INTERFACE
    // --------------------------------------
    input  logic                       scan_en_i,
    input  logic                       scan_capture_i,
    input  logic                       scan_shift_i,
    input  logic                       scan_update_i,
    input  logic                       scan_in_i,
    output logic                       scan_out_o
);

  // --------------------------------------
  // MEMORY
  // --------------------------------------
  (* ram_style = "block" *)
  logic [reg_width-1:0] ram_s[dmemdepth-1:0];

  // --------------------------------------
  // Scan Register
  // --------------------------------------
  logic [reg_width-1:0] scan_sr;

  integer j;

  // --------------------------------------
  // INITIAL VALUES (simulation help)
  // --------------------------------------
  initial begin
    for (j = 0; j < dmemdepth; j++)
      ram_s[j] = '0;

    ram_s[5] = 64'h1122334455667788;
  end

  // --------------------------------------
  // NORMAL WRITE (BYTE ENABLED)
  // --------------------------------------
  genvar i;

  generate
    for(i = 0; i < 8; i++) begin

      always_ff @(posedge clk_i)
      begin
        if (!scan_en_i) begin

          if (wrEn_i) begin
            if (byteEn_i[i]) begin

              ram_s[addr_i[dmem_addr_width-1:3]]
              [((i+1)*8)-1:i*8]

              <=

              data_i[((i+1)*8)-1:i*8];

            end
          end

        end
      end

    end
  endgenerate

  // --------------------------------------
  // NORMAL READ
  // --------------------------------------
  always_ff @(posedge clk_i)
  begin
    data_o <= ram_s[addr_i[dmem_addr_width-1:3]];
  end

  // --------------------------------------
  // SCAN OPERATIONS
  // --------------------------------------
  always_ff @(posedge clk_i)
  begin
    if (scan_en_i) begin

      // CAPTURE
      if (scan_capture_i)
        scan_sr <= ram_s[addr_i[dmem_addr_width-1:3]];

      // SHIFT LEFT (MSB OUT)
      else if (scan_shift_i)
        scan_sr <= {scan_sr[reg_width-2:0], scan_in_i};

      // UPDATE
      else if (scan_update_i)
        ram_s[addr_i[dmem_addr_width-1:3]] <= scan_sr;
    end
  end

  // --------------------------------------
  // SCAN OUTPUT = MSB
  // --------------------------------------
  assign scan_out_o = scan_sr[reg_width-1];

endmodule : as_dmem