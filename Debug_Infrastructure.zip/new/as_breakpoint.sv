`timescale 1ns/1ps

module as_breakpoint #(
    parameter int ADDR_WIDTH = 64
)(
    input  logic                  clk_i,

    // Hardware breakpoint
    input  logic                  hw_bp_enable_i,
    input  logic [ADDR_WIDTH-1:0] hw_bp_addr_i,

    // CPU state
    input  logic [ADDR_WIDTH-1:0] pc_i,

    // Current instruction
    input  logic [31:0]           instr_i,

    output logic                  halt_o
);

localparam logic [31:0]
           EBREAK_INSTR = 32'h00100073;

logic hw_break_hit;
logic sw_break_hit;

// -----------------------------------
// Hardware Breakpoint
// -----------------------------------
assign hw_break_hit =
       hw_bp_enable_i &&
       (pc_i == hw_bp_addr_i);

// -----------------------------------
// Software Breakpoint
// -----------------------------------
assign sw_break_hit =
       (instr_i == EBREAK_INSTR);

// -----------------------------------
// Halt Generation
// -----------------------------------
always_ff @(posedge clk_i) begin

    halt_o <= hw_break_hit ||
              sw_break_hit;

end

endmodule